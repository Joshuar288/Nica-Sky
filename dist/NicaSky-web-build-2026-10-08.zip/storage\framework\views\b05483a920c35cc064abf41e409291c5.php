<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Mi carrito - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-6xl mx-auto py-6">
        <div class="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Mi carrito</h1>
                <p class="text-sm text-gray-400 mt-1">Revisa los productos que has añadido.</p>
            </div>

            <?php if($products->isNotEmpty()): ?>
                <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="text-sm font-semibold text-red-500 hover:text-red-700 transition">
                        <i class="bi bi-trash mr-1"></i>Vaciar carrito
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-6 px-5 py-4 rounded-2xl bg-green-50 border border-green-100 text-sm font-semibold text-green-700">
                <i class="bi bi-check-circle mr-2"></i><?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($products->isEmpty()): ?>
            <div class="bg-white border border-gray-100 rounded-3xl py-20 px-6 text-center shadow-sm">
                <div class="w-16 h-16 mx-auto mb-5 rounded-full bg-gray-50 flex items-center justify-center">
                    <i class="bi bi-bag text-3xl text-gray-300"></i>
                </div>
                <h2 class="text-xl font-bold text-gray-900 mb-2">Tu carrito está vacío</h2>
                <p class="text-sm text-gray-400 mb-6">Explora el catálogo y añade los productos que te interesen.</p>
                <a href="<?php echo e(route('product.index')); ?>" class="inline-flex items-center gap-2 px-6 py-3 bg-[#0b132a] hover:bg-[#162038] text-white rounded-full text-sm font-semibold transition">Ver productos</a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-8 items-start">
                <div class="space-y-4">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row gap-5">
                            <a href="<?php echo e(route('product.show', $product)); ?>" class="w-full sm:w-36 h-36 shrink-0 rounded-xl overflow-hidden bg-gray-50 flex items-center justify-center">
                                <?php if($product->images->isNotEmpty()): ?>
                                    <img src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->title); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <i class="bi bi-image text-3xl text-gray-300"></i>
                                <?php endif; ?>
                            </a>

                            <div class="flex-1 flex flex-col justify-between min-w-0">
                                <div class="flex items-start justify-between gap-4">
                                    <div class="min-w-0">
                                        <a href="<?php echo e(route('product.show', $product)); ?>" class="font-bold text-gray-900 hover:text-[#1d3557] transition"><?php echo e($product->title); ?></a>
                                        <p class="text-sm text-gray-400 mt-1">C$ <?php echo e(number_format($product->price, 2)); ?> / <?php echo e($product->unit); ?></p>
                                    </div>
                                    <form action="<?php echo e(route('cart.destroy', $product)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-gray-300 hover:text-red-500 transition" aria-label="Eliminar <?php echo e($product->title); ?>">
                                            <i class="bi bi-x-lg"></i>
                                        </button>
                                    </form>
                                </div>

                                <div class="flex flex-wrap items-end justify-between gap-4 mt-5">
                                    <form action="<?php echo e(route('cart.update', $product)); ?>" method="POST" class="flex items-center gap-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <label for="quantity-<?php echo e($product->id); ?>" class="text-xs text-gray-400">Cantidad</label>
                                        <input id="quantity-<?php echo e($product->id); ?>" name="quantity" type="number" min="1" max="99" value="<?php echo e($product->cart_quantity); ?>" class="w-16 px-3 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                                        <button type="submit" class="text-xs font-semibold text-[#1d3557] hover:underline">Actualizar</button>
                                    </form>
                                    <p class="font-bold text-[#1d3557]">C$ <?php echo e(number_format($product->cart_subtotal, 2)); ?></p>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <aside class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm lg:sticky lg:top-24">
                    <h2 class="text-lg font-bold text-gray-900 mb-5">Resumen</h2>
                    <div class="flex items-center justify-between text-sm text-gray-500 pb-4 border-b border-gray-100">
                        <span>Productos</span>
                        <span><?php echo e($products->sum('cart_quantity')); ?></span>
                    </div>
                    <div class="flex items-center justify-between mt-5">
                        <span class="font-bold text-gray-900">Total</span>
                        <span class="text-xl font-bold text-[#1d3557]">C$ <?php echo e(number_format($total, 2)); ?></span>
                    </div>
                    <a href="<?php echo e(route('cart.checkout')); ?>" class="mt-6 w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#0b132a] hover:bg-[#162038] text-white rounded-full text-sm font-semibold transition">
                        <i class="bi bi-credit-card"></i>
                        Proceder al pago
                    </a>
                    <p class="text-xs text-gray-400 mt-4">El pago y la entrega se coordinan directamente con cada vendedor.</p>
                </aside>
            </div>
        <?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\cart\index.blade.php ENDPATH**/ ?>