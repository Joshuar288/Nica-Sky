<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Panel de auditoría - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto py-6">
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
                <span class="text-xs font-semibold uppercase tracking-wider text-[#1d3557]">Control y verificación</span>
                <h1 class="text-3xl font-bold text-gray-900 mt-2">Panel de auditoría</h1>
                <p class="text-sm text-gray-400 mt-1">Supervisa las evidencias de envío presentadas por los vendedores.</p>
            </div>
            <a href="<?php echo e(route('auditor.shipments.index')); ?>" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0b132a] text-white text-xs font-semibold hover:bg-[#162038] transition"><i class="bi bi-shield-check"></i> Abrir verificaciones</a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <?php $__currentLoopData = [['Pendientes', $pendingCount, 'clock-history', 'bg-amber-50 text-amber-600'], ['Aprobadas', $approvedCount, 'check-circle', 'bg-green-50 text-green-600'], ['Rechazadas', $rejectedCount, 'x-circle', 'bg-red-50 text-red-600']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $icon, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm"><div class="flex items-center justify-between"><span class="text-sm text-gray-500"><?php echo e($label); ?></span><span class="w-10 h-10 rounded-xl <?php echo e($color); ?> flex items-center justify-center"><i class="bi bi-<?php echo e($icon); ?> text-lg"></i></span></div><p class="text-4xl font-bold text-gray-900 mt-5"><?php echo e($value); ?></p></article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <article class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden mt-8">
            <div class="px-6 py-5 border-b border-gray-100 flex items-center justify-between"><div><h2 class="font-bold text-gray-900">Actividad reciente</h2><p class="text-xs text-gray-400 mt-1">Últimas evidencias registradas.</p></div><a href="<?php echo e(route('auditor.shipments.index')); ?>" class="text-xs font-semibold text-[#1d3557]">Ver todas</a></div>
            <div class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $recentVerifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="px-6 py-4 flex flex-wrap items-center justify-between gap-4"><div><p class="font-semibold text-sm text-gray-800"><?php echo e($verification->seller?->name ?? 'Vendedor eliminado'); ?></p><p class="text-xs text-gray-400"><?php echo e($verification->created_at->diffForHumans()); ?></p></div><span class="px-3 py-1 rounded-full text-xs font-semibold <?php echo e($verification->status === 'approved' ? 'bg-green-50 text-green-700' : ($verification->status === 'rejected' ? 'bg-red-50 text-red-700' : 'bg-amber-50 text-amber-700')); ?>"><?php echo e(['pending' => 'Pendiente', 'approved' => 'Aprobada', 'rejected' => 'Rechazada'][$verification->status]); ?></span></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="p-8 text-sm text-gray-400">Todavía no hay verificaciones de envío.</p>
                <?php endif; ?>
            </div>
        </article>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\dashboard\auditor.blade.php ENDPATH**/ ?>