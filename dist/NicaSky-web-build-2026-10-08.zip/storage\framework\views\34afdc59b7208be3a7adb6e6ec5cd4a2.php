<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Notificaciones - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-4xl mx-auto py-6">
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Notificaciones</h1>
            <p class="text-sm text-gray-400 mt-1">Aquí encontrarás las compras realizadas a tus publicaciones.</p>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-6 p-4 rounded-2xl bg-green-50 border border-green-100 text-sm font-semibold text-green-700"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php ($data = $notification->data); ?>
            <?php if(($data['kind'] ?? null) === 'purchase_refunded'): ?>
                <article class="bg-red-50 border border-red-100 rounded-2xl p-6 shadow-sm mb-5 flex items-start gap-4">
                    <div class="w-11 h-11 shrink-0 rounded-full bg-white text-red-600 flex items-center justify-center"><i class="bi bi-arrow-counterclockwise text-xl"></i></div>
                    <div class="flex-1">
                        <h2 class="font-bold text-red-900"><?php echo e($data['title']); ?></h2>
                        <p class="text-sm text-red-800 mt-1">El pago de tu compra fue devuelto porque no se recibió el comprobante de envío dentro del plazo establecido.</p>
                        <?php if(!empty($data['reason'])): ?><p class="text-xs text-red-700 mt-2"><?php echo e($data['reason']); ?></p><?php endif; ?>
                        <p class="text-xs text-red-600 mt-2">Total devuelto: C$ <?php echo e(number_format($data['total'] ?? 0, 2)); ?></p>
                    </div>
                </article>
            <?php elseif(($data['kind'] ?? null) === 'shipment_submitted'): ?>
                <article class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm mb-5 flex items-start gap-4">
                    <div class="w-11 h-11 shrink-0 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center"><i class="bi bi-shield-check text-xl"></i></div>
                    <div class="flex-1">
                        <h2 class="font-bold text-gray-900"><?php echo e($data['title']); ?></h2>
                        <p class="text-sm text-gray-500 mt-1"><?php echo e($data['seller_name']); ?> envió un comprobante para revisión.</p>
                        <a href="<?php echo e(route('auditor.shipments.index')); ?>" class="inline-flex mt-3 text-sm font-semibold text-[#1d3557] hover:underline">Abrir bandeja de auditoría</a>
                    </div>
                </article>
            <?php elseif(($data['kind'] ?? null) === 'shipment_reviewed'): ?>
                <article class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm mb-5 flex items-start gap-4">
                    <div class="w-11 h-11 shrink-0 rounded-full <?php echo e($data['status'] === 'approved' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'); ?> flex items-center justify-center"><i class="bi bi-clipboard-check text-xl"></i></div>
                    <div><h2 class="font-bold text-gray-900"><?php echo e($data['title']); ?></h2><?php if($data['review_notes']): ?><p class="text-sm text-gray-500 mt-2"><?php echo e($data['review_notes']); ?></p><?php endif; ?></div>
                </article>
            <?php else: ?>
            <article class="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm mb-5">
                <div class="flex items-start gap-4">
                    <div class="w-11 h-11 shrink-0 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
                        <i class="bi bi-bag-check text-xl"></i>
                    </div>
                    <div class="min-w-0 flex-1">
                        <div class="flex flex-wrap items-start justify-between gap-2 mb-4">
                            <div>
                                <h2 class="font-bold text-gray-900"><?php echo e($data['title']); ?></h2>
                                <p class="text-xs text-gray-400"><?php echo e($notification->created_at->diffForHumans()); ?></p>
                            </div>
                            <span class="px-3 py-1 rounded-full <?php echo e(($data['shipment_status'] ?? null) === 'refunded' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'); ?> text-xs font-semibold"><?php echo e($data['payment']['status']); ?></span>
                        </div>

                        <?php if(($data['shipment_status'] ?? null) === 'refunded'): ?>
                            <div class="mb-5 p-4 rounded-xl bg-red-50 border border-red-100 text-red-700 text-sm">
                                <p class="font-semibold">Pago devuelto</p>
                                <p class="mt-1 text-xs">El pago fue devuelto porque no se recibió el comprobante de envío dentro del plazo establecido.</p>
                            </div>
                        <?php elseif(!empty($data['shipment_deadline'])): ?>
                            <p class="mb-5 text-xs text-amber-700">Debes enviar el comprobante antes del <?php echo e(\Carbon\Carbon::parse($data['shipment_deadline'])->format('d/m/Y H:i')); ?>.</p>
                        <?php endif; ?>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-5">
                            <div class="rounded-xl bg-gray-50 p-4">
                                <p class="text-xs text-gray-400 mb-1">Comprador</p>
                                <p class="font-semibold text-gray-800"><?php echo e($data['buyer']['name']); ?></p>
                                <p class="text-gray-500"><?php echo e($data['buyer']['email']); ?></p>
                                <p class="text-gray-500"><?php echo e($data['buyer']['phone']); ?></p>
                            </div>
                            <div class="rounded-xl bg-gray-50 p-4">
                                <p class="text-xs text-gray-400 mb-1">Entrega y pago</p>
                                <p class="font-semibold text-gray-800"><?php echo e($data['delivery_address']); ?></p>
                                <p class="text-gray-500 mt-1"><?php echo e($data['payment']['method']); ?></p>
                            </div>
                        </div>

                        <div class="border-t border-gray-100 pt-4">
                            <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center justify-between gap-4 py-2 text-sm">
                                    <a href="<?php echo e(route('product.show', $item['product_id'])); ?>" class="font-semibold text-gray-700 hover:text-[#1d3557]">
                                        <?php echo e($item['title']); ?> <span class="font-normal text-gray-400">× <?php echo e($item['quantity']); ?></span>
                                    </a>
                                    <span class="text-gray-600">C$ <?php echo e(number_format($item['subtotal'], 2)); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between mt-3 pt-3 border-t border-gray-100 font-bold">
                                <span>Total recibido</span>
                                <span class="text-[#1d3557]">C$ <?php echo e(number_format($data['total'], 2)); ?></span>
                            </div>
                        </div>

                        <?php ($verification = $verifications->get($notification->id)); ?>
                        <div class="mt-5 pt-5 border-t border-gray-100">
                            <?php if(($data['shipment_status'] ?? null) === 'refunded'): ?>
                                <div class="p-4 rounded-xl bg-red-50 text-red-700 text-sm font-semibold">Este pedido ya no admite comprobantes de envío porque el pago fue devuelto.</div>
                            <?php elseif($verification): ?>
                                <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl <?php echo e($verification->status === 'approved' ? 'bg-green-50 text-green-700' : ($verification->status === 'rejected' ? 'bg-red-50 text-red-700' : 'bg-amber-50 text-amber-700')); ?>">
                                    <span class="text-sm font-semibold">Evidencia de envío: <?php echo e(['pending' => 'pendiente de revisión', 'approved' => 'aprobada', 'rejected' => 'rechazada'][$verification->status]); ?></span>
                                    <a href="<?php echo e(route('shipments.evidence', $verification)); ?>" target="_blank" class="text-xs font-semibold underline">Ver comprobante</a>
                                </div>
                            <?php else: ?>
                                <details class="group">
                                    <summary class="cursor-pointer inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#0b132a] text-white text-xs font-semibold"><i class="bi bi-truck"></i> Confirmar envío</summary>
                                    <form action="<?php echo e(route('shipments.store', $notification->id)); ?>" method="POST" enctype="multipart/form-data" class="mt-4 grid sm:grid-cols-2 gap-4 p-5 rounded-2xl bg-gray-50 border border-gray-100">
                                        <?php echo csrf_field(); ?>
                                        <div><label class="block text-xs font-semibold text-gray-600 mb-2">Número de seguimiento</label><input name="tracking_number" maxlength="100" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs" placeholder="Opcional"></div>
                                        <div><label class="block text-xs font-semibold text-gray-600 mb-2">Evidencia del envío</label><input name="evidence" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required class="w-full text-xs text-gray-500 file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-white"></div>
                                        <div class="sm:col-span-2"><label class="block text-xs font-semibold text-gray-600 mb-2">Notas</label><textarea name="seller_notes" rows="2" maxlength="1000" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs" placeholder="Información adicional para el auditor"></textarea></div>
                                        <button type="submit" class="sm:col-span-2 justify-self-start px-5 py-2.5 rounded-full bg-[#1d3557] text-white text-xs font-semibold">Enviar a verificación</button>
                                    </form>
                                </details>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </article>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="bg-white border border-gray-100 rounded-3xl py-20 px-6 text-center shadow-sm">
                <div class="w-16 h-16 mx-auto mb-5 rounded-full bg-gray-50 flex items-center justify-center">
                    <i class="bi bi-bell text-3xl text-gray-300"></i>
                </div>
                <h2 class="text-xl font-bold text-gray-900 mb-2">No tienes notificaciones</h2>
                <p class="text-sm text-gray-400">Las compras de tus productos aparecerán aquí.</p>
            </div>
        <?php endif; ?>

        <div class="mt-6"><?php echo e($notifications->links()); ?></div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\notifications\index.blade.php ENDPATH**/ ?>