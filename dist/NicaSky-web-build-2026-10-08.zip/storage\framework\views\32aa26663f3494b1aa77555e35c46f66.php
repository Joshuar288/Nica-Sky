<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Gestionar usuarios - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto py-6">
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8"><div><span class="text-xs font-semibold uppercase tracking-wider text-[#1d3557]">Administración</span><h1 class="text-3xl font-bold text-gray-900 mt-2">Gestionar usuarios</h1><p class="text-sm text-gray-400 mt-1">Consulta y elimina cuentas no administrativas.</p></div><form method="GET" class="flex gap-2"><input name="q" value="<?php echo e(request('q')); ?>" placeholder="Buscar nombre o correo" class="px-4 py-2.5 rounded-xl border border-gray-200 text-xs"><button type="submit" class="px-4 py-2.5 rounded-xl bg-[#0b132a] text-white text-xs font-semibold">Buscar</button></form></div>
        <?php if(session('success')): ?><div class="mb-6 p-4 rounded-2xl bg-green-50 border border-green-100 text-sm font-semibold text-green-700"><?php echo e(session('success')); ?></div><?php endif; ?>
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"><div class="overflow-x-auto"><table class="w-full text-left"><thead class="bg-gray-50 border-b border-gray-100"><tr><th class="px-6 py-4 text-xs font-semibold text-gray-500">Usuario</th><th class="px-6 py-4 text-xs font-semibold text-gray-500">Contacto</th><th class="px-6 py-4 text-xs font-semibold text-gray-500">Rol</th><th class="px-6 py-4 text-xs font-semibold text-gray-500">Registro</th><th class="px-6 py-4"></th></tr></thead><tbody class="divide-y divide-gray-100">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td class="px-6 py-4"><p class="font-semibold text-sm text-gray-800"><?php echo e($user->name); ?></p><p class="text-xs text-gray-400"><?php echo e($user->name_bussines ?: 'Sin negocio registrado'); ?></p></td><td class="px-6 py-4"><p class="text-sm text-gray-600"><?php echo e($user->email); ?></p><p class="text-xs text-gray-400"><?php echo e($user->phone); ?></p></td><td class="px-6 py-4"><span class="px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 text-[10px] font-semibold"><?php echo e($user->role->label()); ?></span></td><td class="px-6 py-4 text-xs text-gray-500"><?php echo e($user->created_at->format('d/m/Y')); ?></td><td class="px-6 py-4 text-right"><form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" onsubmit="return confirm('¿Eliminar este usuario y sus publicaciones?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="px-3 py-2 rounded-full bg-red-50 text-red-600 text-xs font-semibold hover:bg-red-100">Eliminar</button></form></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="px-6 py-12 text-center text-sm text-gray-400">No hay usuarios para mostrar.</td></tr><?php endif; ?>
        </tbody></table></div></div><div class="mt-6"><?php echo e($users->links()); ?></div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\admin\users\index.blade.php ENDPATH**/ ?>