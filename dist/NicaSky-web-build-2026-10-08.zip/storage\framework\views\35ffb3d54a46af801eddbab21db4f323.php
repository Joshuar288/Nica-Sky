<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> NicaSky - Productos <?php $__env->endSlot(); ?>

    <section class="flex flex-col lg:flex-row gap-8 pb-10">
        <aside class="p-5 w-full lg:w-64 shrink-0 lg:sticky lg:top-20 lg:self-start">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Filtros</h2>

            <form action="<?php echo e(route('product.index')); ?>" method="GET" class="space-y-6">
                <?php if($search !== ''): ?>
                    <input type="hidden" name="q" value="<?php echo e($search); ?>">
                <?php endif; ?>
                <div class="space-y-2">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-700">Precios</h3>
                    <?php $__currentLoopData = $priceOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priceOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                            <input type="radio" name="priceFilter" value="<?php echo e($priceOption); ?>" <?php if((float) $selectedPrice === (float) $priceOption): echo 'checked'; endif; ?> class="text-[#1d3557] focus:ring-[#1d3557]">
                            Hasta C$ <?php echo e(number_format($priceOption, 2)); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white border border-gray-100 rounded-lg p-2 text-center text-xs font-semibold text-slate-700 shadow-sm">
                        Hasta: C$ <?php echo e(number_format($selectedPrice, 2)); ?>

                    </div>
                </div>

                <div>
                    <label for="departmentFilter" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Departamento</label>
                    <select name="departmentFilter" id="departmentFilter" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                        <option value="">Todos los departamentos</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department); ?>" <?php if($selectedDepartment === $department): echo 'selected'; endif; ?>><?php echo e($department); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label for="cityFilter" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Ciudad</label>
                    <select name="cityFilter" id="cityFilter" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                        <option value="">Todas las ciudades</option>
                        <?php $__currentLoopData = $cities->groupBy('name_departament'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department => $departmentCities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e($department); ?>">
                                <?php $__currentLoopData = $departmentCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>" <?php if((int) $selectedCity === $city->id): echo 'selected'; endif; ?>><?php echo e($city->name_city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label for="categoryFilter" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">Categoría</label>
                    <select name="categoryFilter" id="categoryFilter" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                        <option value="">Todas las categorías</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if((int) $selectedCategory === $category->id): echo 'selected'; endif; ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="flex flex-col gap-2">
                    <button type="submit" class="w-full px-4 py-2.5 bg-[#0b132a] hover:bg-[#162038] text-white rounded-xl text-sm font-semibold transition">Aplicar filtros</button>
                    <a href="<?php echo e($search !== '' ? route('product.index', ['q' => $search]) : route('product.index')); ?>" class="w-full px-4 py-2.5 text-center border border-gray-200 hover:bg-gray-100 text-gray-600 rounded-xl text-sm font-semibold transition">Limpiar filtros</a>
                </div>
            </form>
        </aside>

        <div class="flex-1 min-w-0 pt-2">
            <?php if($search !== ''): ?>
                <div class="flex flex-wrap items-center justify-between gap-3 mb-5 px-1">
                    <p class="text-sm text-gray-500">
                        <?php echo e($products->total()); ?> resultados para <span class="font-semibold text-gray-900">“<?php echo e($search); ?>”</span>
                    </p>
                    <a href="<?php echo e(route('product.index')); ?>" class="text-xs font-semibold text-[#1d3557] hover:underline">Quitar búsqueda</a>
                </div>
            <?php endif; ?>
            <section class="grid grid-cols-[repeat(auto-fill,minmax(240px,1fr))] gap-6">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col justify-between relative group hover:shadow-md transition">
                        <form action="<?php echo e(route('cart.store', $product)); ?>" method="POST" class="absolute top-6 left-6 z-10">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="w-8 h-8 bg-[#0b132a] text-white rounded-full flex items-center justify-center shadow-md hover:scale-105 transition" aria-label="Añadir <?php echo e($product->title); ?> al carrito">
                                <i class="bi bi-cart text-xs"></i>
                            </button>
                        </form>

                        <a href="<?php echo e(route('product.show', $product)); ?>" class="h-44 rounded-xl overflow-hidden mb-4 bg-gray-50 flex items-center justify-center relative" aria-label="Ver detalles de <?php echo e($product->title); ?>">
                            <?php if($product->images->isNotEmpty()): ?>
                                <img src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->title); ?>" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                            <?php else: ?>
                                <i class="bi bi-image text-3xl text-gray-300"></i>
                            <?php endif; ?>

                            <span class="absolute bottom-2 right-2 px-2 py-0.5 bg-white/90 backdrop-blur-md rounded-md text-[10px] font-bold text-gray-700 shadow-sm">
                                <?php echo e($product->state); ?>

                            </span>
                        </a>

                        <div>
                            <div class="flex justify-between items-center gap-3 mb-1">
                                <h3 class="min-w-0 flex-1 font-bold text-gray-900 text-sm truncate" title="<?php echo e($product->title); ?>"><?php echo e($product->title); ?></h3>
                                <span class="shrink-0 font-bold text-[#1d3557] text-sm">C$ <?php echo e(number_format($product->price, 2)); ?></span>
                            </div>

                            <p class="text-xs text-gray-400 line-clamp-2 mb-4"><?php echo e($product->description); ?></p>

                            <div class="flex items-center justify-between pt-3 border-t border-gray-100 text-[11px] text-gray-400">
                                <div class="flex items-center gap-2 min-w-0">
                                    <div class="w-5 h-5 rounded-full bg-gray-300 overflow-hidden shrink-0">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($product->user->name)); ?>&background=random" alt="<?php echo e($product->user->name); ?>" class="w-full h-full object-cover">
                                    </div>
                                    <a href="<?php echo e(route('users.show', $product->user)); ?>" class="truncate max-w-[90px] hover:text-[#1d3557] hover:underline"><?php echo e($product->user->name); ?></a>
                                </div>
                                <span>• <?php echo e($product->created_at->diffForHumans()); ?></span>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full bg-white border border-gray-100 rounded-3xl py-16 px-6 text-center shadow-sm">
                        <i class="bi bi-search text-4xl text-gray-300"></i>
                        <h2 class="text-xl font-bold text-gray-900 mt-4">No encontramos productos</h2>
                        <p class="text-sm text-gray-400 mt-2">Prueba cambiando o limpiando los filtros seleccionados.</p>
                    </div>
                <?php endif; ?>
            </section>

            <?php if($products->hasPages()): ?>
                <div class="w-full max-w-full mt-8 pb-4 overflow-x-auto flex justify-center">
                    <?php echo e($products->onEachSide(1)->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views/product/index.blade.php ENDPATH**/ ?>