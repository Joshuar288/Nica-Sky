<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Modificar publicación - NicaSky <?php $__env->endSlot(); ?>

    <div class="max-w-5xl mx-auto bg-white rounded-3xl p-8 shadow-sm border border-gray-100 space-y-8">
        <div class="flex items-center justify-between border-b border-gray-100 pb-6">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Modificar publicación</h1>
                <p class="text-xs text-gray-400 mt-1">Actualiza la información de tu producto.</p>
            </div>
            <a href="<?php echo e(route('myprofile.show')); ?>" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full text-xs font-semibold flex items-center gap-2 transition">
                <i class="bi bi-arrow-left"></i>
                <span>Cancelar</span>
            </a>
        </div>

        <form action="<?php echo e(route('product.update', $product)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div class="lg:col-span-7 space-y-6">
                    <section class="space-y-4">
                        <h2 class="text-base font-bold text-gray-900 border-b border-gray-50 pb-2">Información del producto</h2>

                        <div>
                            <label for="title" class="block text-xs font-semibold text-gray-700 mb-1">Título de la publicación</label>
                            <input id="title" name="title" type="text" value="<?php echo e(old('title', $product->title)); ?>" required maxlength="255"
                                   class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label for="description" class="block text-xs font-semibold text-gray-700 mb-1">Descripción</label>
                            <textarea id="description" name="description" rows="4" required maxlength="1000"
                                      class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a] resize-none"><?php echo e(old('description', $product->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label for="category_id" class="block text-xs font-semibold text-gray-700 mb-1">Categoría</label>
                            <select id="category_id" name="category_id" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                                <?php $__currentLoopData = $categories->groupBy('type_category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <optgroup label="<?php echo e($type); ?>">
                                        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $product->category_id) == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </section>

                    <section class="space-y-4">
                        <h2 class="text-base font-bold text-gray-900 border-b border-gray-50 pb-2">Precio y disponibilidad</h2>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label for="price" class="block text-xs font-semibold text-gray-700 mb-1">Precio</label>
                                <input id="price" name="price" type="number" min="0" step="0.01" value="<?php echo e(old('price', $product->price)); ?>" required
                                       class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="unit" class="block text-xs font-semibold text-gray-700 mb-1">Unidad de medida</label>
                                <input id="unit" name="unit" type="text" maxlength="50" value="<?php echo e(old('unit', $product->unit)); ?>" required
                                       class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                                <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="stock" class="block text-xs font-semibold text-gray-700 mb-1">Stock disponible (opcional)</label>
                                <input id="stock" name="stock" type="number" min="0" value="<?php echo e(old('stock', $product->stock)); ?>"
                                       class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                                <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="state" class="block text-xs font-semibold text-gray-700 mb-1">Estado</label>
                                <select id="state" name="state" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                                    <?php $__currentLoopData = ['Nuevo', 'Usado', 'Reacondicionado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state); ?>" <?php if(old('state', $product->state) === $state): echo 'selected'; endif; ?>><?php echo e($state); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </section>

                    <section class="space-y-3">
                        <h2 class="text-base font-bold text-gray-900 border-b border-gray-50 pb-2">Visibilidad recomendada</h2>
                        <?php if($user->canSelectRecommendations() || $user->plan === 'pro_3'): ?>
                            <?php ($limitReached = $user->canSelectRecommendations() && !$product->is_recommended && $recommendedCount >= $recommendedLimit); ?>
                            <label class="flex items-start gap-3 p-4 rounded-2xl border <?php echo e($limitReached ? 'border-gray-200 bg-gray-50' : 'border-blue-100 bg-blue-50/50 cursor-pointer'); ?>">
                                <input type="checkbox" name="is_recommended" value="1"
                                       <?php if(old('is_recommended', $product->is_recommended)): echo 'checked'; endif; ?> <?php if($limitReached): echo 'disabled'; endif; ?>
                                       class="mt-0.5 rounded text-[#1d3557] focus:ring-[#1d3557]">
                                <span>
                                    <span class="block text-xs font-semibold text-gray-800">Mostrar esta publicación en recomendados</span>
                                    <span class="block text-[11px] text-gray-500 mt-1">
                                        Puedes activar o quitar esta opción cuando quieras.
                                        <?php if($recommendedLimit !== null): ?> Usas <?php echo e($recommendedCount); ?> de <?php echo e($recommendedLimit); ?> espacios. <?php endif; ?>
                                    </span>
                                </span>
                            </label>
                            <?php if($limitReached): ?>
                                <p class="text-xs text-amber-600">Alcanzaste el límite de productos recomendados de tu plan.</p>
                            <?php endif; ?>
                            <?php $__errorArgs = ['is_recommended'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php else: ?>
                            <div class="flex items-center justify-between gap-4 p-4 rounded-2xl border border-gray-200 bg-gray-50">
                                <p class="text-xs text-gray-500">Tu plan actual no permite marcar publicaciones como recomendadas.</p>
                                <a href="<?php echo e(route('premium.show')); ?>" class="shrink-0 text-xs font-semibold text-[#1d3557] hover:underline">Ver planes</a>
                            </div>
                        <?php endif; ?>
                    </section>

                    <section class="space-y-4">
                        <h2 class="text-base font-bold text-gray-900 border-b border-gray-50 pb-2">Imagen</h2>
                        <div>
                            <label for="image" class="block text-xs font-semibold text-gray-700 mb-1">Reemplazar imagen principal (opcional)</label>
                            <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp"
                                   class="block w-full rounded-xl border border-gray-200 text-xs text-gray-600 file:mr-4 file:border-0 file:bg-[#0b132a] file:px-4 file:py-2.5 file:text-xs file:font-semibold file:text-white">
                            <p class="mt-1 text-[11px] text-gray-400">Déjalo vacío para conservar la imagen actual. Máximo 2 MB.</p>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-xs text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </section>
                </div>

                <aside class="lg:col-span-5 bg-gray-50/70 p-5 rounded-2xl border border-gray-100 lg:sticky lg:top-6">
                    <span class="text-[10px] uppercase font-bold text-gray-400 tracking-wider mb-3 block">Imagen actual</span>
                    <div class="h-64 rounded-xl overflow-hidden bg-gray-100 flex items-center justify-center">
                        <?php if($product->images->isNotEmpty()): ?>
                            <img id="imagePreview" src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->title); ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <img id="imagePreview" alt="Vista previa" class="hidden w-full h-full object-cover">
                            <i id="imagePlaceholder" class="bi bi-image text-4xl text-gray-300"></i>
                        <?php endif; ?>
                    </div>
                </aside>
            </div>

            <div class="flex justify-end pt-6 mt-8 border-t border-gray-100">
                <button type="submit" class="px-8 py-3 bg-[#0b132a] hover:bg-[#162038] text-white rounded-full text-xs font-semibold transition shadow-sm">
                    Guardar cambios
                </button>
            </div>
        </form>
    </div>

    <script>
        document.getElementById('image').addEventListener('change', function (event) {
            const file = event.target.files[0];
            if (!file) return;

            const preview = document.getElementById('imagePreview');
            preview.src = URL.createObjectURL(file);
            preview.classList.remove('hidden');
            document.getElementById('imagePlaceholder')?.classList.add('hidden');
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\product\edit.blade.php ENDPATH**/ ?>