<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        NicaSky - Inicio
     <?php $__env->endSlot(); ?>

    <section class= "section-popular-products" id="popular-products">
        <div class= "header-section">
            <h2 class= "title-section">Productos Populares</h2>
            <div class="section-nextprev">
                <button type="button" class="btn-section" id="btn-prev" aria-label="Productos anteriores">&lt;</button>
                <button type="button" class="btn-section" id="btn-next" aria-label="Productos siguientes">&gt;</button>
            </div>
        </div>

        <div class= "body-section-carousel" id="carousell-1">
            <?php $__currentLoopData = $popularProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="min-w-0 max-w-[calc(25%_-_1.6rem)] overflow-hidden bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col flex-[0_0_calc(25%_-_1.6rem)] justify-between relative group hover:shadow-md transition">
                    <!-- Boton Carrito -->
                    <form action="<?php echo e(route('cart.store', $product)); ?>" method="POST" class="absolute top-6 left-6 z-10">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="w-8 h-8 bg-[#0b132a] text-white rounded-full flex items-center justify-center shadow-md hover:scale-105 transition" aria-label="Añadir <?php echo e($product->title); ?> al carrito">
                            <i class="bi bi-cart text-xs"></i>
                        </button>
                    </form>

                    <!-- Imagen del Producto -->
                    <a href="<?php echo e(route('product.show', $product)); ?>" class="h-44 rounded-xl overflow-hidden mb-4 bg-gray-50 flex items-center justify-center relative" aria-label="Ver detalles de <?php echo e($product->title); ?>">
                        <?php if($product->images->isNotEmpty()): ?>
                            <img src="<?php echo e($product->images->first()->url); ?>"
                                alt="<?php echo e($product->title); ?>"
                                class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        <?php else: ?>
                            <i class="bi bi-image text-3xl text-gray-300"></i>
                        <?php endif; ?>

                        <?php if(isset($product->state)): ?>
                            <span class="absolute bottom-2 right-2 px-2 py-0.5 bg-white/90 backdrop-blur-md rounded-md text-[10px] font-bold text-gray-700 shadow-sm">
                                <?php echo e($product->state); ?>

                            </span>
                        <?php endif; ?>
                    </a>

                    <!-- Informacion del Producto -->
                    <div class="min-w-0 overflow-hidden">
                        <div class="flex min-w-0 justify-between items-center gap-3 mb-1">
                            <h3 class="min-w-0 flex-1 font-bold text-gray-900 text-sm truncate" title="<?php echo e($product->title); ?>"><?php echo e($product->title); ?></h3>
                            <span class="shrink-0 font-bold text-[#1d3557] text-sm">C$ <?php echo e(number_format($product->price, 2)); ?></span>
                        </div>

                        <p class="min-h-8 overflow-hidden break-words text-xs text-gray-400 line-clamp-2 mb-4"><?php echo e($product->description); ?></p>

                        <div class="flex items-center justify-between pt-3 border-t border-gray-100 text-[11px] text-gray-400">
                            <div class="flex items-center gap-2">
                                <div class="w-5 h-5 rounded-full bg-gray-300 overflow-hidden shrink-0">
                                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($product->user->name)); ?>&background=random" class="w-full h-full object-cover">
                                </div>
                                <a href="<?php echo e(route('users.show', $product->user)); ?>" class="truncate max-w-[90px] hover:text-[#1d3557] hover:underline"><?php echo e($product->user->name); ?></a>
                            </div>
                            <span>• <?php echo e($product->created_at->diffForHumans()); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="flex justify-center mt-6">
            <a href="<?php echo e(route('product.popular')); ?>" class="px-3 py-2 bg-gray-50 border border-gray-400 text-[#0b132a] rounded-3xl hover:bg-gray-200 transition">Ver todos</a>
        </div>
    </section>

    <section class= "section-popular-products" id="popular-products">
        <div class= "header-section">
            <h2 class= "title-section">Productos Recomendados</h2>
            <div class="section-nextprev">
                <button type="button" class="btn-section" id="btn-prev2" aria-label="Productos recomendados anteriores">&lt;</button>
                <button type="button" class="btn-section" id="btn-next2" aria-label="Productos recomendados siguientes">&gt;</button>
            </div>
        </div>

        <div class= "body-section-carousel" id="carousell-2">
            <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="min-w-0 max-w-[calc(25%_-_1.6rem)] overflow-hidden bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col flex-[0_0_calc(25%_-_1.6rem)] justify-between relative group hover:shadow-md transition">
                    <!-- Boton Carrito -->
                    <form action="<?php echo e(route('cart.store', $product)); ?>" method="POST" class="absolute top-6 left-6 z-10">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="w-8 h-8 bg-[#0b132a] text-white rounded-full flex items-center justify-center shadow-md hover:scale-105 transition" aria-label="Añadir <?php echo e($product->title); ?> al carrito">
                            <i class="bi bi-cart text-xs"></i>
                        </button>
                    </form>

                    <!-- Imagen del Producto -->
                    <a href="<?php echo e(route('product.show', $product)); ?>" class="h-44 rounded-xl overflow-hidden mb-4 bg-gray-50 flex items-center justify-center relative" aria-label="Ver detalles de <?php echo e($product->title); ?>">
                        <?php if($product->images->isNotEmpty()): ?>
                            <img src="<?php echo e($product->images->first()->url); ?>"
                                alt="<?php echo e($product->title); ?>"
                                class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        <?php else: ?>
                            <i class="bi bi-image text-3xl text-gray-300"></i>
                        <?php endif; ?>

                        <?php if(isset($product->state)): ?>
                            <span class="absolute bottom-2 right-2 px-2 py-0.5 bg-white/90 backdrop-blur-md rounded-md text-[10px] font-bold text-gray-700 shadow-sm">
                                <?php echo e($product->state); ?>

                            </span>
                        <?php endif; ?>
                    </a>

                    <!-- Informacion del Producto -->
                    <div class="min-w-0 overflow-hidden">
                        <div class="flex min-w-0 justify-between items-center gap-3 mb-1">
                            <h3 class="min-w-0 flex-1 font-bold text-gray-900 text-sm truncate" title="<?php echo e($product->title); ?>"><?php echo e($product->title); ?></h3>
                            <span class="shrink-0 font-bold text-[#1d3557] text-sm">C$ <?php echo e(number_format($product->price, 2)); ?></span>
                        </div>

                        <p class="min-h-8 overflow-hidden break-words text-xs text-gray-400 line-clamp-2 mb-4"><?php echo e($product->description); ?></p>

                        <div class="flex items-center justify-between pt-3 border-t border-gray-100 text-[11px] text-gray-400">
                            <div class="flex items-center gap-2">
                                <div class="w-5 h-5 rounded-full bg-gray-300 overflow-hidden shrink-0">
                                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($product->user->name)); ?>&background=random" class="w-full h-full object-cover">
                                </div>
                                <a href="<?php echo e(route('users.show', $product->user)); ?>" class="truncate max-w-[90px] hover:text-[#1d3557] hover:underline"><?php echo e($product->user->name); ?></a>
                            </div>
                            <span>• <?php echo e($product->created_at->diffForHumans()); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="flex justify-center mt-6">
            <a href="<?php echo e(route('product.recommended')); ?>" class="px-3 py-2 bg-gray-50 border border-gray-400 text-[#0b132a] rounded-3xl hover:bg-gray-200 transition">Ver todos</a>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views/home.blade.php ENDPATH**/ ?>