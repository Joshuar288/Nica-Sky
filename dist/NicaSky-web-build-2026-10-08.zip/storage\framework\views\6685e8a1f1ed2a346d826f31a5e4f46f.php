<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Planes - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto py-8">
        <div class="text-center max-w-2xl mx-auto mb-10">
            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-[#1d3557] text-xs font-semibold mb-4"><i class="bi bi-gem"></i>Planes NicaSky</span>
            <h1 class="text-4xl font-bold text-gray-900">Elige cuántos productos quieres destacar</h1>
            <p class="text-sm leading-7 text-gray-500 mt-3">Los productos recomendados obtienen mayor visibilidad en la página de inicio.</p>
        </div>

        <?php if(session('success')): ?>
            <div class="max-w-3xl mx-auto mb-6 px-5 py-4 rounded-2xl bg-green-50 border border-green-100 text-sm font-semibold text-green-700">
                <i class="bi bi-check-circle mr-2"></i><?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php $__errorArgs = ['plan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="max-w-3xl mx-auto mb-6 px-5 py-4 rounded-2xl bg-red-50 border border-red-100 text-sm font-semibold text-red-700"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php
            $plans = [
                ['key' => 'free', 'name' => 'Gratuito', 'price' => 'C$ 0', 'limit' => 'Sin productos recomendados', 'limit2' => 'Sin límite de publicaciones', 'limit3' => 'Insignia Premium', 'limit4' => 'Publicidad no Intrusiva', 'rank' => 0],
                ['key' => 'pro_1', 'name' => 'Plan plus', 'price' => 'C$ 199', 'limit' => 'Hasta 5 productos recomendados', 'limit2' => 'Prioridades en Busquedas',  'limit3' => 'Insignia Premium', 'limit4' => 'Sin publicidad', 'rank' => 1],
                ['key' => 'pro_2', 'name' => 'Plan Pro', 'price' => 'C$ 399', 'limit' => 'Hasta 15 productos recomendados', 'limit2' => 'Soporte prioritario',  'limit3' => 'Personalización avanzada en tienda Digital', 'limit4' => 'Todos los beneficios de planes anteriores', 'rank' => 2],
                ['key' => 'pro_3', 'name' => 'Plan Nica', 'price' => 'C$ 699', 'limit' => 'Todos tus productos recomendados', 'limit2' => 'Acceso anticipado a nuevas funciones',  'limit3' => 'Destacar Perfil',  'limit4' => 'Todos los beneficios de planes anteriores', 'limit4', 'rank' => 3],
            ];
            $ranks = ['free' => 0, 'pro_1' => 1, 'pro_2' => 2, 'pro_3' => 3];
            $currentRank = $ranks[$user->plan] ?? 0;
        ?>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="relative bg-white rounded-3xl border <?php echo e($user->plan === $plan['key'] ? 'border-[#1d3557] ring-2 ring-[#1d3557]/10' : 'border-gray-100'); ?> p-6 shadow-sm flex flex-col">
                    <?php if($user->plan === $plan['key']): ?>
                        <span class="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-[#1d3557] text-white text-[10px] font-bold">PLAN ACTUAL</span>
                    <?php endif; ?>

                    <h2 class="text-xl font-bold text-gray-900"><?php echo e($plan['name']); ?></h2>
                    <p class="text-3xl font-bold text-[#1d3557] mt-4"><?php echo e($plan['price']); ?></p>
                    <p class="text-xs text-gray-400 mt-1">Pago mensual</p>

                    <ul class="space-y-3 my-7 text-sm text-gray-600 flex-1">
                        <li class="flex gap-2"><i class="bi bi-check-circle-fill text-green-500"></i><?php echo e($plan['limit']); ?></li>
                        <li class="flex gap-2"><i class="bi bi-check-circle-fill text-green-500"></i><?php echo e($plan['limit2']); ?></li>
                        <?php if($plan['key'] !== 'free'): ?>
                            <li class="flex gap-2"><i class="bi bi-check-circle-fill text-green-500"></i><?php echo e($plan['limit3']); ?></li>
                            <li class="flex gap-2"><i class="bi bi-check-circle-fill text-green-500"></i><?php echo e($plan['limit4']); ?></li>
                        <?php else: ?>
                            <li class="flex gap-2"><i class="bi bi-x-circle-fill text-gray-300"></i><?php echo e($plan['limit3']); ?></li>
                            <li class="flex gap-2"><i class="bi bi-x-circle-fill text-gray-300"></i><?php echo e($plan['limit4']); ?></li>
                        <?php endif; ?>
                    </ul>

                    <?php if($user->plan === $plan['key']): ?>
                        <div class="w-full py-3 rounded-full bg-gray-100 text-center text-xs font-semibold text-gray-500">Activo</div>
                    <?php elseif($plan['rank'] < $currentRank || $plan['key'] === 'free'): ?>
                        <div class="w-full py-3 rounded-full bg-gray-50 text-center text-xs font-semibold text-gray-300">No disponible</div>
                    <?php else: ?>
                        <a href="<?php echo e(route('premium.checkout', $plan['key'])); ?>" class="block w-full py-3 rounded-full bg-[#0b132a] hover:bg-[#162038] text-white text-center text-xs font-semibold transition">Elegir <?php echo e($plan['name']); ?></a>
                    <?php endif; ?>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\premium\show.blade.php ENDPATH**/ ?>