<div class="card-product">
    <div class="card-product-header">
        <button type="button">
            <i class="bi bi-cart text-xs"></i>
        </button>
    </div>

    <div class="card-product-body">

    </div>

    <div class="card-product-footer">

    </div>
</div>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\components\card-products.blade.php ENDPATH**/ ?>