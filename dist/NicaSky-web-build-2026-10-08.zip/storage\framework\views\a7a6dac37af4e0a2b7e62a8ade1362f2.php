<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Revisar publicaciones - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto py-6">
        <div class="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-8">
            <div><span class="text-xs font-semibold uppercase tracking-wider text-[#1d3557]">Moderación</span><h1 class="text-3xl font-bold text-gray-900 mt-2">Revisar publicaciones</h1><p class="text-sm text-gray-400 mt-1">Aprueba, rechaza o elimina publicaciones de la plataforma.</p></div>
            <form method="GET" class="flex flex-wrap gap-2">
                <input name="q" value="<?php echo e(request('q')); ?>" placeholder="Buscar título o usuario" class="px-4 py-2.5 rounded-xl border border-gray-200 text-xs">
                <select name="status" class="px-4 py-2.5 rounded-xl border border-gray-200 text-xs"><option value="">Todos los estados</option><option value="approved" <?php if(request('status') === 'approved'): echo 'selected'; endif; ?>>Aprobadas</option><option value="rejected" <?php if(request('status') === 'rejected'): echo 'selected'; endif; ?>>Rechazadas</option><option value="pending" <?php if(request('status') === 'pending'): echo 'selected'; endif; ?>>Pendientes</option></select>
                <button type="submit" class="px-4 py-2.5 rounded-xl bg-[#0b132a] text-white text-xs font-semibold">Filtrar</button>
            </form>
        </div>

        <?php if(session('success')): ?><div class="mb-6 p-4 rounded-2xl bg-green-50 border border-green-100 text-sm font-semibold text-green-700"><?php echo e(session('success')); ?></div><?php endif; ?>

        <?php ($moderationLabels = ['pending' => 'Pendiente', 'approved' => 'Aprobada', 'rejected' => 'Rechazada']); ?>
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                    <div class="flex flex-col lg:flex-row gap-5 lg:items-center">
                        <div class="w-24 h-24 shrink-0 rounded-xl overflow-hidden bg-gray-50 flex items-center justify-center">
                            <?php if($product->images->isNotEmpty()): ?><img src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->title); ?>" class="w-full h-full object-cover"><?php else: ?><i class="bi bi-image text-2xl text-gray-300"></i><?php endif; ?>
                        </div>
                        <div class="min-w-0 flex-1"><div class="flex flex-wrap items-center gap-2"><h2 class="font-bold text-gray-900 truncate"><?php echo e($product->title); ?></h2><span class="px-2 py-1 rounded-full text-[10px] font-semibold <?php echo e($product->moderation_status === 'rejected' ? 'bg-red-50 text-red-700' : ($product->moderation_status === 'pending' ? 'bg-amber-50 text-amber-700' : 'bg-green-50 text-green-700')); ?>"><?php echo e($moderationLabels[$product->moderation_status] ?? 'Pendiente'); ?></span></div><p class="text-sm text-gray-500 mt-1"><?php echo e($product->user?->name ?? 'Usuario eliminado'); ?> · <?php echo e($product->category?->name ?? 'Sin categoría'); ?></p><p class="text-sm text-gray-600 mt-2 line-clamp-2"><?php echo e($product->description); ?></p><?php if($product->moderation_notes): ?><p class="text-xs text-red-600 mt-2">Nota: <?php echo e($product->moderation_notes); ?></p><?php endif; ?></div>
                        <div class="flex flex-wrap gap-2 shrink-0"><a href="<?php echo e(route('product.show', $product)); ?>" class="px-4 py-2 rounded-full border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50">Ver</a><form action="<?php echo e(route('admin.products.moderate', $product)); ?>" method="POST" class="flex gap-2"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><input type="hidden" name="moderation_status" value="approved"><button type="submit" class="px-4 py-2 rounded-full bg-green-600 text-white text-xs font-semibold hover:bg-green-700">Aprobar</button></form><details class="relative"><summary class="cursor-pointer list-none px-4 py-2 rounded-full bg-red-50 text-red-700 text-xs font-semibold hover:bg-red-100">Rechazar</summary><form action="<?php echo e(route('admin.products.moderate', $product)); ?>" method="POST" class="absolute right-0 top-11 z-20 w-64 p-4 bg-white border border-gray-100 rounded-2xl shadow-xl"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><input type="hidden" name="moderation_status" value="rejected"><textarea name="moderation_notes" required maxlength="1000" rows="3" class="w-full rounded-xl border border-gray-200 text-xs" placeholder="Motivo del rechazo"></textarea><button type="submit" class="mt-2 w-full py-2 rounded-xl bg-red-600 text-white text-xs font-semibold">Confirmar rechazo</button></form></details><form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('¿Eliminar esta publicación?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="px-4 py-2 rounded-full bg-gray-100 text-gray-600 text-xs font-semibold hover:bg-gray-200">Eliminar</button></form></div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="bg-white rounded-2xl border border-gray-100 p-12 text-center text-sm text-gray-400">No hay publicaciones para mostrar.</div>
            <?php endif; ?>
        </div>
        <div class="mt-6"><?php echo e($products->links()); ?></div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\admin\products\index.blade.php ENDPATH**/ ?>