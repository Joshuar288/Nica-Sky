<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class City extends Model
{
    use HasFactory;

    protected $fillable = [
        'name_departament',
        'name_city',
    ];

    /**
     * Get all of the users for the City
     */
    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }
}
