<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Panel de administración - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto py-6">
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
                <span class="text-xs font-semibold uppercase tracking-wider text-[#1d3557]">Administración general</span>
                <h1 class="text-3xl font-bold text-gray-900 mt-2">Panel de administración</h1>
                <p class="text-sm text-gray-400 mt-1">Resumen de la actividad actual de NicaSky.</p>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="<?php echo e(route('admin.products.index')); ?>" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-white border border-gray-200 text-[#0b132a] text-xs font-semibold hover:bg-gray-50 transition"><i class="bi bi-box-seam"></i> Revisar publicaciones</a>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-white border border-gray-200 text-[#0b132a] text-xs font-semibold hover:bg-gray-50 transition"><i class="bi bi-people"></i> Gestionar usuarios</a>
                <a href="<?php echo e(route('auditor.shipments.index')); ?>" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0b132a] text-white text-xs font-semibold hover:bg-[#162038] transition"><i class="bi bi-shield-check"></i> Revisar envíos</a>
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
            <?php $__currentLoopData = [
                ['Usuarios', $totalUsers, 'people', 'bg-blue-50 text-blue-600'],
                ['Compradores y vendedores', $totalCustomers, 'person-check', 'bg-emerald-50 text-emerald-600'],
                ['Publicaciones', $totalProducts, 'box-seam', 'bg-violet-50 text-violet-600'],
                ['Recomendados', $recommendedProducts, 'stars', 'bg-amber-50 text-amber-600'],
                ['Envíos pendientes', $pendingShipments, 'truck', 'bg-rose-50 text-rose-600'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $icon, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
                    <div class="flex items-center justify-between"><span class="text-xs text-gray-500"><?php echo e($label); ?></span><span class="w-9 h-9 rounded-xl <?php echo e($color); ?> flex items-center justify-center"><i class="bi bi-<?php echo e($icon); ?>"></i></span></div>
                    <p class="text-3xl font-bold text-gray-900 mt-4"><?php echo e($value); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="grid lg:grid-cols-2 gap-6 mt-8">
            <article class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div class="px-6 py-5 border-b border-gray-100 flex items-center justify-between"><h2 class="font-bold text-gray-900">Usuarios recientes</h2><a href="<?php echo e(route('profile.edit')); ?>" class="text-xs font-semibold text-[#1d3557]">Mi perfil</a></div>
                <div class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="px-6 py-4 flex items-center justify-between gap-4"><div class="min-w-0"><p class="font-semibold text-sm text-gray-800 truncate"><?php echo e($user->name); ?></p><p class="text-xs text-gray-400 truncate"><?php echo e($user->email); ?></p></div><span class="shrink-0 px-2.5 py-1 rounded-full bg-gray-100 text-gray-500 text-[10px] font-semibold"><?php echo e($user->role->label()); ?></span></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="p-6 text-sm text-gray-400">No hay usuarios registrados.</p>
                    <?php endif; ?>
                </div>
            </article>

            <article class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div class="px-6 py-5 border-b border-gray-100 flex items-center justify-between"><h2 class="font-bold text-gray-900">Publicaciones recientes</h2><a href="<?php echo e(route('product.index')); ?>" class="text-xs font-semibold text-[#1d3557]">Ver productos</a></div>
                <div class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $recentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="px-6 py-4 flex items-center justify-between gap-4"><div class="min-w-0"><p class="font-semibold text-sm text-gray-800 truncate"><?php echo e($product->title); ?></p><p class="text-xs text-gray-400 truncate"><?php echo e($product->user?->name ?? 'Sin usuario'); ?></p></div><span class="shrink-0 font-semibold text-sm text-[#1d3557]">C$ <?php echo e(number_format($product->price, 2)); ?></span></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="p-6 text-sm text-gray-400">No hay publicaciones registradas.</p>
                    <?php endif; ?>
                </div>
            </article>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>