<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e($product->title); ?> - NicaSky
     <?php $__env->endSlot(); ?>

    <section class="max-w-6xl mx-auto py-6">
        <a href="<?php echo e(url()->previous()); ?>" class="inline-flex items-center gap-2 mb-6 text-sm font-semibold text-gray-500 hover:text-[#0b132a] transition">
            <i class="bi bi-arrow-left"></i>
            Volver
        </a>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 bg-white rounded-3xl border border-gray-100 p-6 lg:p-8 shadow-sm">
            <div class="rounded-2xl overflow-hidden bg-gray-50 min-h-[320px] lg:min-h-[480px] flex items-center justify-center">
                <?php if($product->images->isNotEmpty()): ?>
                    <img src="<?php echo e($product->images->first()->url); ?>"
                         alt="<?php echo e($product->title); ?>"
                         class="w-full h-full max-h-[560px] object-cover">
                <?php else: ?>
                    <div class="flex flex-col items-center gap-3 text-gray-300">
                        <i class="bi bi-image text-6xl"></i>
                        <span class="text-sm">Producto sin imagen</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="flex flex-col">
                <div class="flex flex-wrap gap-2 mb-4">
                    <?php if($product->category): ?>
                        <span class="px-3 py-1 bg-blue-50 text-[#1d3557] rounded-full text-xs font-semibold">
                            <?php echo e($product->category->name); ?>

                        </span>
                    <?php endif; ?>
                    <span class="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-semibold">
                        <?php echo e($product->state); ?>

                    </span>
                </div>

                <h1 class="text-3xl font-bold text-gray-900 mb-3"><?php echo e($product->title); ?></h1>
                <p class="text-3xl font-bold text-[#1d3557] mb-6">
                    C$ <?php echo e(number_format($product->price, 2)); ?>

                    <span class="text-sm font-normal text-gray-400">/ <?php echo e($product->unit); ?></span>
                </p>

                <div class="border-t border-gray-100 pt-6 mb-8">
                    <h2 class="font-bold text-gray-900 mb-3">Descripción</h2>
                    <p class="text-sm leading-7 text-gray-600 whitespace-pre-line"><?php echo e($product->description); ?></p>
                </div>

                <dl class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8 text-sm">
                    <div class="rounded-xl bg-gray-50 p-4">
                        <dt class="text-gray-400 mb-1">Disponibilidad</dt>
                        <dd class="font-semibold text-gray-800">
                            <?php echo e(is_null($product->stock) ? 'Consultar' : $product->stock . ' disponibles'); ?>

                        </dd>
                    </div>
                    <div class="rounded-xl bg-gray-50 p-4">
                        <dt class="text-gray-400 mb-1">Publicado</dt>
                        <dd class="font-semibold text-gray-800"><?php echo e($product->created_at->diffForHumans()); ?></dd>
                    </div>
                    <div class="rounded-xl bg-gray-50 p-4">
                        <dt class="text-gray-400 mb-1">Visitas</dt>
                        <dd class="font-semibold text-gray-800">
                            <i class="bi bi-eye mr-1 text-gray-400"></i><?php echo e(number_format($product->views_count)); ?>

                        </dd>
                    </div>
                </dl>

                <div class="mt-auto border-t border-gray-100 pt-6 flex items-center justify-between gap-4">
                    <div class="flex items-center gap-3 min-w-0">
                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($product->user->name)); ?>&background=random"
                             alt="<?php echo e($product->user->name); ?>"
                             class="w-11 h-11 rounded-full object-cover">
                        <div class="min-w-0">
                            <a href="<?php echo e(route('users.show', $product->user)); ?>" class="block font-semibold text-gray-900 truncate hover:text-[#1d3557] hover:underline"><?php echo e($product->user->name); ?></a>
                            <?php if($product->user->city): ?>
                                <p class="text-xs text-gray-400">
                                    <i class="bi bi-geo-alt"></i>
                                    <?php echo e($product->user->city->name_departament); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if($product->moderation_status === 'approved'): ?>
                    <form action="<?php echo e(route('cart.store', $product)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="shrink-0 inline-flex items-center gap-2 px-5 py-3 bg-[#0b132a] hover:bg-[#162038] text-white rounded-full text-sm font-semibold transition">
                            <i class="bi bi-cart-plus"></i>
                            Añadir al carrito
                        </button>
                    </form>
                    <?php else: ?>
                        <?php ($moderationLabels = ['pending' => 'Pendiente', 'rejected' => 'Rechazada']); ?>
                        <span class="shrink-0 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-amber-50 text-amber-700 text-xs font-semibold">
                            <i class="bi bi-hourglass-split"></i>
                            <?php echo e($moderationLabels[$product->moderation_status] ?? 'No aprobada'); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="mt-5 px-5 py-4 rounded-2xl bg-green-50 border border-green-100 text-sm font-semibold text-green-700">
                <i class="bi bi-check-circle mr-2"></i><?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($relatedProducts->isNotEmpty()): ?>
            <div class="mt-12">
                <div class="flex items-end justify-between gap-4 mb-6">
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900">Productos relacionados</h2>
                        <p class="text-sm text-gray-400 mt-1">
                            Más productos de la categoría <?php echo e($product->category->name); ?>

                        </p>
                    </div>
                    <a href="<?php echo e(route('product.index')); ?>" class="text-sm font-semibold text-[#1d3557] hover:underline">
                        Ver todos
                    </a>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
                    <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col group hover:shadow-md transition">
                            <a href="<?php echo e(route('product.show', $relatedProduct)); ?>"
                               class="h-44 rounded-xl overflow-hidden mb-4 bg-gray-50 flex items-center justify-center relative"
                               aria-label="Ver detalles de <?php echo e($relatedProduct->title); ?>">
                                <?php if($relatedProduct->images->isNotEmpty()): ?>
                                    <img src="<?php echo e($relatedProduct->images->first()->url); ?>"
                                         alt="<?php echo e($relatedProduct->title); ?>"
                                         class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                                <?php else: ?>
                                    <i class="bi bi-image text-3xl text-gray-300"></i>
                                <?php endif; ?>

                                <span class="absolute bottom-2 right-2 px-2 py-0.5 bg-white/90 backdrop-blur-md rounded-md text-[10px] font-bold text-gray-700 shadow-sm">
                                    <?php echo e($relatedProduct->state); ?>

                                </span>
                            </a>

                            <div class="flex items-start justify-between gap-3 mb-2">
                                <a href="<?php echo e(route('product.show', $relatedProduct)); ?>" class="font-bold text-gray-900 text-sm truncate hover:text-[#1d3557]" title="<?php echo e($relatedProduct->title); ?>">
                                    <?php echo e($relatedProduct->title); ?>

                                </a>
                                <span class="shrink-0 font-bold text-[#1d3557] text-sm">
                                    C$ <?php echo e(number_format($relatedProduct->price, 2)); ?>

                                </span>
                            </div>

                            <p class="text-xs text-gray-400 line-clamp-2 mb-4"><?php echo e($relatedProduct->description); ?></p>

                            <div class="mt-auto flex items-center justify-between pt-3 border-t border-gray-100 text-[11px] text-gray-400">
                                <a href="<?php echo e(route('users.show', $relatedProduct->user)); ?>" class="truncate hover:text-[#1d3557] hover:underline"><?php echo e($relatedProduct->user->name); ?></a>
                                <span><?php echo e($relatedProduct->created_at->diffForHumans()); ?></span>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\product\show.blade.php ENDPATH**/ ?>