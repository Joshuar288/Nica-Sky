<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Productos recomendados - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto py-6">
        <div class="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Productos recomendados</h1>
                <p class="text-sm text-gray-400 mt-1">Publicaciones destacadas de vendedores Premium.</p>
            </div>
            <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center gap-2 text-sm font-semibold text-gray-500 hover:text-[#0b132a] transition">
                <i class="bi bi-arrow-left"></i>Volver al inicio
            </a>
        </div>

        <div class="grid grid-cols-[repeat(auto-fill,minmax(240px,1fr))] gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col justify-between relative group hover:shadow-md transition">
                    <span class="absolute top-6 left-6 z-10 inline-flex items-center gap-1 px-2.5 py-1 bg-[#0b132a] text-white rounded-full text-[10px] font-semibold shadow-md">
                        <i class="bi bi-gem"></i>Premium
                    </span>

                    <a href="<?php echo e(route('product.show', $product)); ?>" class="h-44 rounded-xl overflow-hidden mb-4 bg-gray-50 flex items-center justify-center relative" aria-label="Ver detalles de <?php echo e($product->title); ?>">
                        <?php if($product->images->isNotEmpty()): ?>
                            <img src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->title); ?>" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        <?php else: ?>
                            <i class="bi bi-image text-3xl text-gray-300"></i>
                        <?php endif; ?>
                        <span class="absolute bottom-2 right-2 px-2 py-0.5 bg-white/90 rounded-md text-[10px] font-bold text-gray-700 shadow-sm"><?php echo e($product->state); ?></span>
                    </a>

                    <div>
                        <div class="flex justify-between items-center gap-3 mb-1">
                            <h2 class="min-w-0 flex-1 font-bold text-gray-900 text-sm truncate" title="<?php echo e($product->title); ?>"><?php echo e($product->title); ?></h2>
                            <span class="shrink-0 font-bold text-[#1d3557] text-sm">C$ <?php echo e(number_format($product->price, 2)); ?></span>
                        </div>
                        <p class="text-xs text-gray-400 line-clamp-2 mb-4"><?php echo e($product->description); ?></p>
                        <div class="flex items-center justify-between pt-3 border-t border-gray-100 text-[11px] text-gray-400">
                            <div class="flex items-center gap-2 min-w-0">
                                <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($product->user->name)); ?>&background=random" alt="<?php echo e($product->user->name); ?>" class="w-5 h-5 rounded-full object-cover">
                                <a href="<?php echo e(route('users.show', $product->user)); ?>" class="truncate max-w-[110px] hover:text-[#1d3557] hover:underline"><?php echo e($product->user->name); ?></a>
                            </div>
                            <span><?php echo e($product->created_at->diffForHumans()); ?></span>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full bg-white border border-gray-100 rounded-3xl py-16 px-6 text-center shadow-sm">
                    <i class="bi bi-gem text-4xl text-gray-300"></i>
                    <h2 class="text-xl font-bold text-gray-900 mt-4">Todavía no hay productos recomendados</h2>
                    <p class="text-sm text-gray-400 mt-2">Los productos de vendedores Premium aparecerán aquí.</p>
                </div>
            <?php endif; ?>
        </div>

        <?php if($recommendedProducts->hasPages()): ?>
            <div class="mt-8"><?php echo e($recommendedProducts->links()); ?></div>
        <?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\product\recommended.blade.php ENDPATH**/ ?>