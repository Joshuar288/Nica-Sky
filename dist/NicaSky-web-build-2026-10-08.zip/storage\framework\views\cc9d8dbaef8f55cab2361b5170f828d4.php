<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'NicaSky'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/css/nicastyle.css']); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-gray-50 font-sans flex h-screen overflow-hidden">

    <!-- Sidebar Fijo a la Izquierda -->
    <aside class="w-64 bg-[#0b132a] text-white flex flex-col justify-between p-5 min-h-screen flex-shrink-0 sticky top-0 h-screen">
        <div>
            <!-- Logo -->
            <div class="flex justify-center -mt-5 mb-2">
                <a href="<?php echo e(auth()->user()->isAdmin() ? route('admin.dashboard') : (auth()->user()->isAuditor() ? route('auditor.dashboard') : route('home'))); ?>" class="flex items-center justify-center" aria-label="Ir al inicio">
                    <img src="<?php echo e(asset('images/Imagotipo_NicaSky.svg')); ?>" alt="NicaSky Logo" class="block w-44 h-auto object-contain">
                </a>
            </div>

            <!-- Menú de Navegación -->
            <nav class="space-y-1.5">
                <?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                        <i class="bi bi-speedometer2 text-base"></i>
                        <span>Panel admin</span>
                    </a>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition <?php echo e(request()->routeIs('admin.products.*') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                        <i class="bi bi-clipboard-check text-base"></i>
                        <span>Revisar publicaciones</span>
                    </a>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition <?php echo e(request()->routeIs('admin.users.*') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                        <i class="bi bi-people text-base"></i>
                        <span>Gestionar usuarios</span>
                    </a>
                <?php elseif(auth()->user()->isAuditor()): ?>
                    <a href="<?php echo e(route('auditor.dashboard')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition <?php echo e(request()->routeIs('auditor.dashboard') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                        <i class="bi bi-speedometer2 text-base"></i>
                        <span>Panel auditor</span>
                    </a>
                <?php endif; ?>
                <?php if(!auth()->user()->isAuditor()): ?>
                <a href="<?php echo e(route('home')); ?>"
                   class="flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition <?php echo e(request()->routeIs('home') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                    <i class="bi bi-house-door text-base"></i>
                    <span>Inicio</span>
                </a>
                <a href="<?php echo e(route('product.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:text-white hover:bg-[#162038] font-medium text-sm transition <?php echo e(request()->routeIs('product.*') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                    <i class="bi bi-grid text-base"></i>
                    <span>Productos</span>
                </a>
                <?php endif; ?>
                <?php if(!auth()->user()->isAuditor()): ?>
                    <a href="<?php echo e(route('myprofile.show')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:text-white hover:bg-[#162038] font-medium text-sm transition <?php echo e(request()->routeIs('myprofile.*', 'profile.*') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                        <i class="bi bi-bar-chart text-base"></i>
                        <span>Mi Perfil</span>
                    </a>
                    <a href="<?php echo e(route('premium.show')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition <?php echo e(request()->routeIs('premium.*') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                        <i class="bi bi-gem text-base"></i>
                        <span>Plan Premium</span>
                    </a>
                <?php endif; ?>
                <?php if(auth()->user()->canAudit()): ?>
                    <a href="<?php echo e(route('auditor.shipments.index')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition <?php echo e(request()->routeIs('auditor.shipments.*') ? 'bg-[#1e2942] text-white' : 'text-gray-400 hover:text-white hover:bg-[#162038]'); ?>">
                        <i class="bi bi-shield-check text-base"></i>
                        <span>Verificar envíos</span>
                    </a>
                <?php endif; ?>
            </nav>
        </div>

        <!-- Botón de Sesión (Login / Logout) -->
        <div class="pt-4 border-t border-gray-800">
            <?php if(auth()->guard()->check()): ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#1d3557] hover:bg-[#25416b] text-white rounded-2xl text-sm font-semibold transition">
                        <i class="bi bi-box-arrow-right"></i>
                        Cerrar sesión
                    </button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#25416b] hover:bg-[#1d3557] text-white rounded-2xl text-sm font-semibold transition">
                    <i class="bi bi-box-arrow-in-right"></i>
                    Iniciar sesión
                </a>
            <?php endif; ?>
        </div>
    </aside>

    <!-- Contenido Dinámico de cada Vista -->
    <main class="flex-1 px-8 my-5 h-full overflow-y-auto bg-[#f8f8f8]">
        <!-- Header Superior Común -->
        <header class="flex justify-end items-center gap-3 rounded-full p-2 mb-1 mt-0 sticky top-0 bg-[#ffffff] z-10">
            <?php if(request()->routeIs('product.index')): ?>
                <form action="<?php echo e(route('product.index')); ?>" method="GET" class="flex-1 max-w-xl mr-auto">
                    <?php $__currentLoopData = request()->except(['q', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!is_array($value)): ?>
                            <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative">
                        <i class="bi bi-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Buscar producto, categoría o vendedor..." class="w-full pl-10 pr-24 py-2.5 rounded-full border border-gray-200 text-xs text-gray-800 outline-none focus:border-[#0b132a] focus:ring-1 focus:ring-[#0b132a]">
                        <button type="submit" class="absolute right-1.5 top-1/2 -translate-y-1/2 px-4 py-2 bg-[#0b132a] hover:bg-[#162038] text-white rounded-full text-xs font-semibold transition">Buscar</button>
                    </div>
                </form>
            <?php endif; ?>
            <a href="<?php echo e(route('notifications.index')); ?>" class="relative w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-600 hover:bg-gray-50 shadow-sm" aria-label="Ver notificaciones">
                <i class="bi bi-bell text-lg"></i>
                <?php ($unreadNotificationCount = auth()->user()->unreadNotifications()->count()); ?>
                <?php if($unreadNotificationCount > 0): ?>
                    <span class="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                        <?php echo e($unreadNotificationCount > 99 ? '99+' : $unreadNotificationCount); ?>

                    </span>
                <?php endif; ?>
            </a>
            <?php if(!auth()->user()->isAuditor()): ?>
                <a href="<?php echo e(route('cart.index')); ?>" class="relative w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-600 hover:bg-gray-50 shadow-sm" aria-label="Ver carrito">
                    <i class="bi bi-bag text-lg"></i>
                    <?php ($cartCount = array_sum(session('cart', []))); ?>
                    <?php if($cartCount > 0): ?>
                        <span class="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-[#1d3557] text-white text-[10px] font-bold flex items-center justify-center">
                            <?php echo e($cartCount > 99 ? '99+' : $cartCount); ?>

                        </span>
                    <?php endif; ?>
                </a>
            <?php endif; ?>
            <?php if(!auth()->user()->isAuditor()): ?>
                <a href="<?php echo e(route('profile.edit')); ?>" class="w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-600 hover:bg-gray-50 shadow-sm" aria-label="Editar perfil">
                    <i class="bi bi-person-circle text-lg"></i>
                </a>
            <?php endif; ?>
        </header>

        <!-- Aquí se renderizará el contenido propio de cada página -->
        <?php echo e($slot); ?>

    </main>

</body>
</html>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\components\sidebar-layout.blade.php ENDPATH**/ ?>