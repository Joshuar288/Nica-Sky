<?php if (isset($component)) { $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($user->name_bussines ?? $user->name); ?> - NicaSky <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto py-6">
        <div class="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 mb-8">
            <div class="flex flex-col md:flex-row gap-6 items-start">
                <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($user->name_bussines ?? $user->name)); ?>&background=0b132a&color=fff&size=128"
                     alt="<?php echo e($user->name); ?>"
                     class="w-28 h-28 rounded-full object-cover border-2 border-gray-100 shadow-sm">

                <div class="flex-1 min-w-0">
                    <div class="flex flex-wrap items-center gap-3">
                        <h1 class="text-3xl font-bold text-gray-900"><?php echo e($user->name_bussines ?? $user->name); ?></h1>
                        <?php if($user->is_verified): ?>
                            <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-blue-50 text-[#1d3557] text-xs font-semibold">
                                <i class="bi bi-patch-check-fill"></i>Premium
                            </span>
                        <?php endif; ?>
                    </div>
                    <?php if($user->name_bussines): ?>
                        <p class="text-sm text-gray-500 mt-1">Atendido por <?php echo e($user->name); ?></p>
                    <?php endif; ?>

                    <div class="flex flex-wrap gap-x-5 gap-y-2 mt-4 text-sm text-gray-500">
                        <?php if($user->city): ?>
                            <span><i class="bi bi-geo-alt mr-1"></i><?php echo e($user->city->name_city); ?>, <?php echo e($user->city->name_departament); ?></span>
                        <?php endif; ?>
                        <span><i class="bi bi-telephone mr-1"></i><?php echo e($user->phone); ?></span>
                        <span><i class="bi bi-envelope mr-1"></i><?php echo e($user->email); ?></span>
                    </div>

                    <?php if($user->description): ?>
                        <p class="mt-5 pt-5 border-t border-gray-100 text-sm leading-7 text-gray-600 whitespace-pre-line"><?php echo e($user->description); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="flex items-end justify-between gap-4 mb-6">
            <div>
                <h2 class="text-2xl font-bold text-gray-900">Publicaciones</h2>
                <p class="text-sm text-gray-400 mt-1">Productos publicados por este vendedor.</p>
            </div>
            <span class="text-sm font-semibold text-gray-500"><?php echo e($products->total()); ?> productos</span>
        </div>

        <div class="grid grid-cols-[repeat(auto-fill,minmax(240px,1fr))] gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col group hover:shadow-md transition">
                    <a href="<?php echo e(route('product.show', $product)); ?>" class="h-44 rounded-xl overflow-hidden mb-4 bg-gray-50 flex items-center justify-center relative">
                        <?php if($product->images->isNotEmpty()): ?>
                            <img src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->title); ?>" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        <?php else: ?>
                            <i class="bi bi-image text-3xl text-gray-300"></i>
                        <?php endif; ?>
                        <span class="absolute bottom-2 right-2 px-2 py-0.5 bg-white/90 rounded-md text-[10px] font-bold text-gray-700"><?php echo e($product->state); ?></span>
                    </a>
                    <div class="flex items-start justify-between gap-3 mb-2">
                        <a href="<?php echo e(route('product.show', $product)); ?>" class="min-w-0 flex-1 font-bold text-gray-900 text-sm truncate hover:text-[#1d3557]" title="<?php echo e($product->title); ?>"><?php echo e($product->title); ?></a>
                        <span class="shrink-0 font-bold text-[#1d3557] text-sm">C$ <?php echo e(number_format($product->price, 2)); ?></span>
                    </div>
                    <p class="text-xs text-gray-400 line-clamp-2"><?php echo e($product->description); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full bg-white rounded-3xl border border-dashed border-gray-200 py-16 text-center">
                    <i class="bi bi-box-seam text-4xl text-gray-300"></i>
                    <p class="text-sm text-gray-400 mt-3">Este usuario todavía no tiene publicaciones.</p>
                </div>
            <?php endif; ?>
        </div>

        <?php if($products->hasPages()): ?>
            <div class="mt-8 pb-4"><?php echo e($products->onEachSide(1)->links()); ?></div>
        <?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $attributes = $__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__attributesOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12)): ?>
<?php $component = $__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12; ?>
<?php unset($__componentOriginal1f7b3c69a858611a4ccc5f2ea9729c12); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Nica-Sky\resources\views\myprofile\public.blade.php ENDPATH**/ ?>